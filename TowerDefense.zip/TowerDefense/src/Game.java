import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;

public class Game extends JPanel implements Runnable, MouseListener, KeyListener {
    private static final int UI_BAR_HEIGHT = 80;

    // Map
    private Map map;

    // Game entities
    private final java.util.List<Tower> towers = new ArrayList<>();
    private final java.util.List<Enemy> enemies = new ArrayList<>();
    private final java.util.List<Projectile> projectiles = new ArrayList<>();

    // Sprites
    private BufferedImage gunTowerSprite, iceTowerSprite, bombTowerSprite;
    private BufferedImage normalEnemySprite, fastEnemySprite, tankEnemySprite;
    private BufferedImage tileGrass, tilePath, tileSpawn, tileGoal;
    private BufferedImage moneyIcon, healthIcon, upgradeButtonIcon;

    // Game state
    private int playerMoney = 500;
    private int playerLives = 20;
    private int selectedTowerType = 0; // 0 = none, 1 = gun, 2 = ice, 3 = bomb

    // Wave manager
    private WaveManager waveManager;

    // Thread
    private Thread gameThread;
    private boolean running = false;

    public Game() {
        setFocusable(true);
        requestFocus();
        addMouseListener(this);
        addKeyListener(this);

        loadSprites();
        map = new Map();

        // Random seed for wave generation
        long seed = new Random().nextLong();
        waveManager = new WaveManager(seed);

        setPreferredSize(new Dimension(Map.WIDTH * Map.TILE_SIZE, Map.HEIGHT * Map.TILE_SIZE + UI_BAR_HEIGHT));
    }

    private void loadSprites() {
        try {
            gunTowerSprite = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Towers/GunTower.png"));
            iceTowerSprite = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Towers/IceTower.png"));
            bombTowerSprite = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Towers/BombTower.png"));

            normalEnemySprite = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Enemies/normalEnemy.png"));
            fastEnemySprite   = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Enemies/fastEnemy.png"));
            tankEnemySprite   = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Enemies/tankEnemy.png"));

            tileGrass = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Tiles/tile_grass.png"));
            tilePath  = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Tiles/tile_path.png"));
            tileSpawn = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Tiles/tile_spawn.png"));
            tileGoal  = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Tiles/tile_goal.png"));

            moneyIcon  = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Button/moneyIcon.png"));
            healthIcon = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Button/healthIcon.png"));
            upgradeButtonIcon = ImageIO.read(new File("/home/jordans/TowerDefense/Assets/Button/upgradeButton.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void start() {
        running = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        while (running) {
            long now = System.nanoTime();
            double dt = (now - lastTime) / 1e9; // seconds
            lastTime = now;

            updateGame(dt);
            repaint();

            try { Thread.sleep(16); } // ~60 FPS
            catch (InterruptedException e) { e.printStackTrace(); }
        }
    }

    private void updateGame(double dt) {
        if (playerLives <= 0) {
            running = false;
            return;
        }

        // Update enemies
        Iterator<Enemy> ei = enemies.iterator();
        while (ei.hasNext()) {
            Enemy e = ei.next();
            e.update(dt);
            if (e.isDead()) {
                playerMoney += e.getReward();
                ei.remove();
            } else if (e.reachedEnd()) {
                playerLives -= e.getDamage();
                ei.remove();
            }
        }

        // Update projectiles
        Iterator<Projectile> pi = projectiles.iterator();
        while (pi.hasNext()) {
            Projectile p = pi.next();
            p.update(dt);
            if (p.hasExploded()) pi.remove();
        }

        // Update towers
        for (Tower t : towers) {
            t.update(dt, enemies, projectiles);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // Draw map
        map.draw(g2);

        // Draw towers
        for (Tower t : towers) t.draw(g2);

        // Draw projectiles
        for (Projectile p : projectiles) p.draw(g2);

        // Draw enemies
        for (Enemy e : enemies) e.draw(g2);

        // Draw tower ranges
        for (Tower t : towers) {
            Point gp = t.getGridPosition();
            int radius = t.getRadius();
            g2.setColor(new Color(0, 0, 255, 50));
            g2.fillOval(gp.x * Map.TILE_SIZE - radius + Map.TILE_SIZE / 2,
                        gp.y * Map.TILE_SIZE - radius + Map.TILE_SIZE / 2,
                        radius * 2, radius * 2);
        }

        // Draw HUD
        drawHUD(g2);
    }

    private void drawHUD(Graphics2D g2) {
        // Background panel
        g2.setColor(new Color(0,0,0,150));
        g2.fillRect(0, Map.HEIGHT * Map.TILE_SIZE, Map.WIDTH * Map.TILE_SIZE, UI_BAR_HEIGHT);

        // Money
        g2.drawImage(moneyIcon, 10, Map.HEIGHT * Map.TILE_SIZE + 5, 32, 32, null);
        g2.setColor(Color.YELLOW);
        g2.drawString(String.valueOf(playerMoney), 50, Map.HEIGHT * Map.TILE_SIZE + 25);

        // Lives
        g2.drawImage(healthIcon, 120, Map.HEIGHT * Map.TILE_SIZE + 5, 32, 32, null);
        g2.setColor(Color.RED);
        g2.drawString(String.valueOf(playerLives), 160, Map.HEIGHT * Map.TILE_SIZE + 25);

        // Keybinds & prices
        g2.setColor(Color.WHITE);
        g2.drawString("1 - Gun Tower ($100)", 300, Map.HEIGHT * Map.TILE_SIZE + 20);
        g2.drawString("2 - Ice Tower ($150)", 300, Map.HEIGHT * Map.TILE_SIZE + 40);
        g2.drawString("3 - Bomb Tower ($200)", 300, Map.HEIGHT * Map.TILE_SIZE + 60);
        g2.drawString("SPACE - Start Next Wave", 450, Map.HEIGHT * Map.TILE_SIZE + 40);

        // Game Over message
        if (!running && playerLives <= 0) {
            g2.setColor(Color.RED);
            g2.drawString("GAME OVER! Press ESC to exit or restart the program.", 600, Map.HEIGHT * Map.TILE_SIZE + 60);
        }
    }

    // MouseListener
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX() / Map.TILE_SIZE;
        int y = e.getY() / Map.TILE_SIZE;
        if (y >= Map.HEIGHT) return;

        if (selectedTowerType != 0 && playerMoney >= 100) {
            Tower t;
            switch(selectedTowerType){
                case 1: t = new GunTower(x,y,gunTowerSprite); break;
                case 2: t = new IceTower(x,y,iceTowerSprite); break;
                case 3: t = new BombTower(x,y,bombTowerSprite); break;
                default: return;
            }
            towers.add(t);
            playerMoney -= 100;
        }
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}

    // KeyListener
    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_1: selectedTowerType = 1; break;
            case KeyEvent.VK_2: selectedTowerType = 2; break;
            case KeyEvent.VK_3: selectedTowerType = 3; break;
            case KeyEvent.VK_SPACE:
                waveManager.startNextWave(enemies, map.getPath());
                break;
            case KeyEvent.VK_ESCAPE:
                System.exit(0);
                break;
        }
    }
    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
}
