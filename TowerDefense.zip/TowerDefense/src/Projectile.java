import java.awt.*;
import java.awt.geom.Point2D;
import java.util.List;

public class Projectile {
    private Point2D.Double position;
    private Enemy target;
    private String type;
    private int damage;
    private double speed = 300.0;
    private boolean exploded = false;

    public Projectile(double x, double y, Enemy target, String type, int damage){
        this.position = new Point2D.Double(x,y);
        this.target = target;
        this.type = type;
        this.damage = damage;
    }

    public void update(double dt){
        if(target==null || target.isDead()){ exploded=true; return; }
        double dx = target.getPosition().x - position.x;
        double dy = target.getPosition().y - position.y;
        double dist = Math.sqrt(dx*dx+dy*dy);

        if(dist<4.0){
            if("ice".equals(type)) target.slow(0.5);
            else target.takeDamage(damage);
            exploded = true;
            return;
        }

        double factor = (speed*dt)/dist;
        position.x += dx*factor;
        position.y += dy*factor;
    }

    public boolean hasExploded(){ return exploded; }
    public Point2D.Double getPosition(){ return position; }

    public void draw(Graphics2D g2){
        g2.setColor(Color.YELLOW);
        g2.fillOval((int)position.x,(int)position.y,24,24);
    }
}
