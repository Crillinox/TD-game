import java.awt.Point;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;

public class WaveManager {
    private int currentWave = 0;
    private Random random;

    public WaveManager(long seed) {
        random = new Random(seed);
    }

    /**
     * Start the next wave.
     * @param enemies List of enemies in the game to add new enemies to.
     * @param path The path the enemies should follow.
     */
    public void startNextWave(List<Enemy> enemies, List<Point> path) {
        currentWave++;
        int enemyCount = 5 + currentWave * 2; // Increase number per wave

        for (int i = 0; i < enemyCount; i++) {
            int type = random.nextInt(3); // 0=Normal, 1=Fast, 2=Tank
            switch (type) {
                case 0:
                    enemies.add(new NormalEnemy(path));
                    break;
                case 1:
                    enemies.add(new FastEnemy(path));
                    break;
                case 2:
                    enemies.add(new TankEnemy(path));
                    break;
            }
        }
    }

    /**
     * Optional: can be used for UI to display the current wave number.
     */
    public int getCurrentWave() {
        return currentWave;
    }
}
